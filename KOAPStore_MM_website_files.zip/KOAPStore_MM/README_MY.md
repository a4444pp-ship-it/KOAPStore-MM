# KOAPStore MM — ဖုန်းနဲ့ အခမဲ့တင်သုံးရန် လမ်းညွှန်

## ပါဝင်တာ
- Mobile-friendly Game Top-up storefront demo
- PUBG Mobile, Mobile Legends, Free Fire, Honor of Kings, Genshin Impact, Call of Duty: Mobile
- Package ရွေးချယ်ခြင်း၊ Player ID/Server ID ထည့်ခြင်း၊ KBZPay/WavePay ရွေးချယ်ခြင်း
- Order draft ကို ဖန်တီးပြီး copy လုပ်နိုင်ခြင်း

## အရေးကြီးတဲ့ ကန့်သတ်ချက်
ဒီဖိုင်တွေက **frontend demo** ဖြစ်ပြီး အခုချိန်မှာ အမှန်တကယ်ငွေလက်ခံတာ၊ ငွေလွှဲအတည်ပြုတာ၊ order database ထဲသိမ်းတာ၊ အလိုအလျောက် UC/diamond ဖြည့်တာ မလုပ်နိုင်သေးပါ။ ဖော်ပြထားတဲ့ဈေးနှုန်းတွေဟာ နမူနာဈေးတွေဖြစ်ပြီး live price မဟုတ်ပါ။

Auto top-up ကို ဖွင့်ရန်:
1. ဂိမ်းတစ်ခုချင်းစီအတွက် တရားဝင်/ခွင့်ပြုထားတဲ့ top-up provider နဲ့ reseller account ရယူပါ။
2. Provider API docs, product IDs, API credentials, callback/webhook rules ကို ယူပါ။
3. API secret key ကို browser/frontend ထဲ မထည့်ပါ။ Backend/server-side function နဲ့သာ သိမ်းပါ။
4. Order create endpoint, payment verification, provider fulfillment, failure/refund handling, duplicate-order protection, logs နဲ့ admin authentication ကို backend မှာ ဆောက်ပါ။
5. KBZPay/WavePay အတွက် သင့် account နဲ့ ကိုက်ညီတဲ့ တရားဝင် merchant/payment integration ရနိုင်မရ စစ်ပါ။ လက်ခံအကောင့်နံပါတ်/QR ကို လက်တွေ့ရရှိပြီးမှ သတ်မှတ်ပါ။
6. Test transaction တွေပြီးမှ live launch လုပ်ပါ။

## အခမဲ့ static hosting (ဖုန်းနဲ့)
အလွယ်ဆုံးက GitHub Pages သို့မဟုတ် Cloudflare Pages တစ်ခုခုပါ။ Vite project ဖြစ်တဲ့အတွက်:
- Build command: `npm run build`
- Output folder: `dist`

### GitHub Pages (အလွယ်ဆုံး upload workflow)
1. GitHub အကောင့်ဖွင့်/ဝင်ပါ။
2. New public repository တစ်ခုဖန်တီးပါ (ဥပမာ `koapstore-mm`).
3. ဒီ ZIP ကိုဖြည်ပြီး project ထဲက ဖိုင်တွေကို repository ထဲ upload လုပ်ပါ။
4. GitHub Pages ကိုဖွင့်ရန် `Settings → Pages` သို့သွားပြီး deploy source ရွေးပါ။
5. Vite build မလုပ်ဘဲ root မှ `index.html` ကို Pages တင်တာက ဒီ project ရဲ့ source imports (`/src.js`) ကို production မှာ မသေချာစေနိုင်ပါ။ ထို့ကြောင့် GitHub Actions မှ `npm install` နှင့် `npm run build` လုပ်ပြီး `dist` ကို deploy လုပ်ရန် သင့်တော်ပါတယ်။ Cloudflare Pages မှာလည်း Git repo ချိတ်ပြီး build command `npm run build`, output `dist` သတ်မှတ်နိုင်ပါတယ်။

## Local preview
Node.js ရှိတဲ့ ကွန်ပျူတာ/VPS မှာ:
```bash
npm install
npm run dev
```
ဖုန်းတစ်လုံးတည်းနဲ့လုပ်ရင် Cloudflare Pages က GitHub repo ကိုချိတ်ပြီး build/deploy လုပ်တာ အဆင်ပြေပါတယ်။

## Launch မတိုင်ခင် ပြင်ရန်
- Package prices ကို provider ရဲ့ live pricing နဲ့ အစားထိုးရန်
- ဆိုင်ရဲ့ တရားဝင် support Telegram/contact link ထည့်ရန်
- KPay/WavePay merchant details နဲ့ payment verification ထည့်ရန်
- Backend + database + admin login + provider API integration ထည့်ရန်
- Privacy notice, refund/cancel policy, order status page ထည့်ရန်

### GitHub Pages အတွက် auto-build
ZIP ထဲမှာ `.github/workflows/deploy.yml` နဲ့ `vite.config.js` ပါဝင်ပါတယ်။ Repository ကို `main` branch ထဲ upload လုပ်ပြီး GitHub repo ရဲ့ `Settings → Pages` မှာ **Source: GitHub Actions** ကိုရွေးပါ။ `main` ထဲ push လုပ်တာနဲ့ workflow က site ကို build/deploy လုပ်ပေးပါမယ်။ Actions tab မှာ အစိမ်းရောင် success ဖြစ်ပြီးနောက် Pages URL ကိုဖွင့်ကြည့်ပါ။
