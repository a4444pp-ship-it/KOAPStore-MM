import './style.css';

const games = [
  { id:'pubg', name:'PUBG Mobile', category:'Battle Royale', icon:'🎯', color:'#f5a623', packages:[
    {id:'pubg60',label:'60 UC',price:4500},{id:'pubg325',label:'325 UC',price:22000},{id:'pubg660',label:'660 UC',price:42000},{id:'pubg1800',label:'1800 UC',price:106000},{id:'pubg3850',label:'3850 UC',price:210000}
  ]},
  { id:'mlbb', name:'Mobile Legends', category:'MOBA', icon:'💎', color:'#49a6ff', packages:[
    {id:'ml86',label:'86 Diamonds',price:5500},{id:'ml172',label:'172 Diamonds',price:10500},{id:'ml257',label:'257 Diamonds',price:15500},{id:'mlWeekly',label:'Weekly Pass',price:8500}
  ]},
  { id:'freefire', name:'Free Fire', category:'Battle Royale', icon:'🔥', color:'#ff6b35', packages:[
    {id:'ff100',label:'100 Diamonds',price:4000},{id:'ff310',label:'310 Diamonds',price:11000},{id:'ff520',label:'520 Diamonds',price:18000},{id:'ff1060',label:'1060 Diamonds',price:35000}
  ]},
  { id:'hok', name:'Honor of Kings', category:'MOBA', icon:'👑', color:'#f0c75e', packages:[
    {id:'hok80',label:'80 Tokens',price:4500},{id:'hok240',label:'240 Tokens',price:12000},{id:'hok400',label:'400 Tokens',price:19500}
  ]},
  { id:'genshin', name:'Genshin Impact', category:'Adventure', icon:'✨', color:'#9b8cff', packages:[
    {id:'gi60',label:'60 Genesis Crystals',price:5000},{id:'gi300',label:'300 + 30 Crystals',price:23000},{id:'gi980',label:'980 + 110 Crystals',price:69000}
  ]},
  { id:'codm', name:'Call of Duty: Mobile', category:'Shooter', icon:'🪖', color:'#a7c66b', packages:[
    {id:'cod80',label:'80 CP',price:5000},{id:'cod420',label:'420 CP',price:22000},{id:'cod880',label:'880 CP',price:43000}
  ]}
];

const state = { game: 'pubg', packageId: 'pubg660', query: '', payment: 'kpay' };
const $ = (s) => document.querySelector(s);
const money = (n) => new Intl.NumberFormat('en-US').format(n) + ' MMK';
const getGame = () => games.find(g => g.id === state.game);
const getPackage = () => getGame().packages.find(p => p.id === state.packageId) || getGame().packages[0];

function render() {
  const visibleGames = games.filter(g => (g.name + ' ' + g.category).toLowerCase().includes(state.query.toLowerCase()));
  $('#app').innerHTML = `
    <header class="topbar">
      <a class="brand" href="#"><span class="brand-mark">K</span><span>KOAP<span class="brand-accent">Store</span> <small>MM</small></span></a>
      <a class="help-link" href="#order">Order <span>↗</span></a>
    </header>
    <main>
      <section class="hero">
        <div class="hero-copy">
          <div class="eyebrow"><span class="live-dot"></span> GAME TOP-UP STORE</div>
          <h1>Power up your<br><span>next victory.</span></h1>
          <p>ဂိမ်းအတွက် လိုအပ်တဲ့ Top-up တွေကို တစ်နေရာတည်းမှာ ရွေးချယ်ပြီး Order တင်လိုက်ပါ။</p>
          <div class="hero-pills"><span>⚡ Fast order</span><span>🔒 Secure checkout</span><span>📱 Mobile friendly</span></div>
        </div>
        <div class="hero-art" aria-hidden="true"><div class="orb orb-one"></div><div class="orb orb-two"></div><div class="controller">🎮</div><div class="hero-star">✦</div><div class="hero-chip">KOAP<br><b>STORE</b></div></div>
      </section>

      <section class="section">
        <div class="section-head"><div><div class="eyebrow">EXPLORE</div><h2>Choose your game</h2></div><div class="game-count">${games.length} GAMES</div></div>
        <label class="search"><span>⌕</span><input id="search" placeholder="ဂိမ်းရှာရန်..." value="${escapeHtml(state.query)}"><kbd>SEARCH</kbd></label>
        <div class="games-grid" id="games-grid">
          ${visibleGames.map(g => `<button class="game-card ${state.game===g.id?'selected':''}" data-game="${g.id}" style="--game-color:${g.color}">
            <span class="game-icon">${g.icon}</span><span class="game-info"><b>${g.name}</b><small>${g.category}</small></span><span class="game-arrow">↗</span>
          </button>`).join('') || '<p class="empty">ဂိမ်းမတွေ့ပါ။</p>'}
        </div>
      </section>

      <section class="order-layout" id="order">
        <div class="order-main panel">
          <div class="section-head compact"><div><div class="eyebrow">TOP-UP CENTER</div><h2>Place an order</h2></div><span class="step">01 / 03</span></div>
          <div class="selected-game" style="--game-color:${getGame().color}"><span class="selected-icon">${getGame().icon}</span><div><b>${getGame().name}</b><small>Select a package below</small></div><span class="verified">● READY</span></div>
          <label class="field-label">Select package</label>
          <div class="packages">
            ${getGame().packages.map(p => `<button class="package ${getPackage().id===p.id?'chosen':''}" data-package="${p.id}"><span>${p.label}</span><b>${money(p.price)}</b>${getPackage().id===p.id?'<i>✓</i>':''}</button>`).join('')}
          </div>
          <div class="form-grid">
            <label class="field"><span>Player ID <em>*</em></span><input id="playerId" placeholder="ဂိမ်း Player ID" inputmode="numeric" autocomplete="off"></label>
            <label class="field"><span>Server ID <small>(လိုအပ်ပါက)</small></span><input id="serverId" placeholder="Server ID" inputmode="numeric" autocomplete="off"></label>
          </div>
          <p class="note">⚠️ Password / OTP မတောင်းပါ။ Player ID ကို သေချာစစ်ဆေးပါ။</p>
          <label class="field-label">Payment method</label>
          <div class="payments">
            <button class="payment ${state.payment==='kpay'?'chosen':''}" data-payment="kpay"><span class="pay-logo kpay">K</span><span><b>KBZPay</b><small>Mobile wallet</small></span><span class="radio"></span></button>
            <button class="payment ${state.payment==='wavepay'?'chosen':''}" data-payment="wavepay"><span class="pay-logo wave">W</span><span><b>WavePay</b><small>Mobile wallet</small></span><span class="radio"></span></button>
          </div>
          <div class="notice"><b>ငွေပေးချေမှုအကြောင်း</b><p>ဒီ Demo မှာ ငွေလက်ခံအကောင့်/QR မထည့်ရသေးပါ။ အောက်က Order ခလုတ်က အော်ဒါအချက်အလက်ကို ပြင်ဆင်ပေးမယ်။ အမှန်တကယ်ငွေလက်ခံခြင်းနဲ့ Auto top-up ကို မချိတ်ဆက်ရသေးပါ။</p></div>
          <button class="primary-btn" id="submit-order">Order အချက်အလက် ပြင်ဆင်မယ် <span>→</span></button>
          <p class="tiny-center">Demo storefront · No real payment is processed</p>
        </div>

        <aside class="summary panel">
          <div class="eyebrow">YOUR ORDER</div><h3>Order summary</h3>
          <div class="summary-game"><span class="summary-icon">${getGame().icon}</span><div><b>${getGame().name}</b><small>${getPackage().label}</small></div></div>
          <div class="summary-line"><span>Package price</span><b>${money(getPackage().price)}</b></div>
          <div class="summary-line"><span>Service fee</span><b>0 MMK*</b></div>
          <div class="summary-total"><span>Total</span><b>${money(getPackage().price)}</b></div>
          <div class="summary-foot">*Demo price only. Confirm final prices with your provider before launch.</div>
          <div class="trust-list"><span>✓ No password needed</span><span>✓ Order review before payment</span><span>✓ Customer support needed for live store</span></div>
          <div class="support-box"><span>Need help?</span><b>KOAPStore MM Support</b><small>Set your official Telegram/contact link before publishing.</small></div>
        </aside>
      </section>
      <section class="bottom-banner"><div><div class="eyebrow">KOAPSTORE MM</div><h2>Your games. One store.</h2><p>အလွယ်တကူ ရွေးချယ်၊ Order တင်၊ အခြေအနေစစ်ဆေးနိုင်မယ့် Game Top-up Portal။</p></div><div class="banner-icon">✦</div></section>
    </main>
    <footer><a class="brand" href="#"><span class="brand-mark">K</span><span>KOAP<span class="brand-accent">Store</span> <small>MM</small></span></a><span>© ${new Date().getFullYear()} KOAPStore MM · Demo storefront</span></footer>
    <div class="toast" id="toast" role="status"></div>
  `;
  bind();
}
function escapeHtml(s){return s.replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function toast(msg){const t=$('#toast'); t.textContent=msg; t.classList.add('show'); setTimeout(()=>t.classList.remove('show'),3000);}
function bind(){
  $('#search').addEventListener('input', e=>{const pos=e.target.selectionStart;state.query=e.target.value;const grid=$('#games-grid');const vis=games.filter(g=>(g.name+' '+g.category).toLowerCase().includes(state.query.toLowerCase()));grid.innerHTML=vis.map(g=>`<button class="game-card ${state.game===g.id?'selected':''}" data-game="${g.id}" style="--game-color:${g.color}"><span class="game-icon">${g.icon}</span><span class="game-info"><b>${g.name}</b><small>${g.category}</small></span><span class="game-arrow">↗</span></button>`).join('')||'<p class="empty">ဂိမ်းမတွေ့ပါ။</p>';bindGameCards();e.target.focus();e.target.setSelectionRange(pos,pos);});
  bindGameCards();
  document.querySelectorAll('[data-package]').forEach(b=>b.addEventListener('click',()=>{state.packageId=b.dataset.package;render();}));
  document.querySelectorAll('[data-payment]').forEach(b=>b.addEventListener('click',()=>{state.payment=b.dataset.payment;render();}));
  $('#submit-order').addEventListener('click',()=>{
    const player=$('#playerId').value.trim(), server=$('#serverId').value.trim();
    if(!player){toast('Player ID ကို အရင်ဖြည့်ပါ။');$('#playerId').focus();return;}
    const p=getPackage(),g=getGame();
    const msg=`KOAPStore MM — Order draft\nGame: ${g.name}\nPackage: ${p.label}\nPrice: ${money(p.price)}\nPlayer ID: ${player}\nServer ID: ${server||'N/A'}\nPayment: ${state.payment==='kpay'?'KBZPay':'WavePay'}\n\nဒီစာက demo order draft ဖြစ်ပါတယ်။ ငွေလွှဲခြင်း/UC ဖြည့်ခြင်း မလုပ်ရသေးပါ။`;
    const modal=document.createElement('div');modal.className='modal-backdrop';modal.innerHTML=`<div class="modal"><button class="modal-close" aria-label="Close">×</button><div class="eyebrow">ORDER DRAFT</div><h2>အော်ဒါအချက်အလက်</h2><pre>${escapeHtml(msg)}</pre><p>ဒီဟာက စမ်းသပ်ရန်သာဖြစ်ပြီး ငွေမလွှဲပါနှင့်။ Live provider နဲ့ payment verification မချိတ်ရသေးပါ။</p><button class="primary-btn copy-order">စာသား Copy လုပ်မယ် <span>↗</span></button></div>`;
    document.body.appendChild(modal);
    modal.querySelector('.modal-close').onclick=()=>modal.remove();
    modal.addEventListener('click',e=>{if(e.target===modal)modal.remove()});
    modal.querySelector('.copy-order').onclick=async()=>{try{await navigator.clipboard.writeText(msg);toast('Order draft ကို Copy လုပ်ပြီးပါပြီ။')}catch{toast('Copy မရပါက စာသားကို ကိုယ်တိုင်ရွေးပါ။')}};
  });
}
function bindGameCards(){document.querySelectorAll('[data-game]').forEach(b=>b.addEventListener('click',()=>{state.game=b.dataset.game;state.packageId=getGame().packages[0].id;render();$('#order').scrollIntoView({behavior:'smooth',block:'start'});}));}
render();
